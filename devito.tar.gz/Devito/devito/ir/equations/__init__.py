from devito.ir.equations.equation import *  # noqa
