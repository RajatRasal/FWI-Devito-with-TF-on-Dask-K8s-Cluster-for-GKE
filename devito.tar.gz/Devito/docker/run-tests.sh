#!/usr/bin/env bash

PYTHONPATH=/app /venv/bin/python -m pytest tests/
